import axios from 'axios';

const Movie_API_BASE_URL = "http://localhost:8200/movie";

class MovieService {

    getMovie(){
        return axios.get(Movie_API_BASE_URL);
    }

    createMovie(movie){
        return axios.post(Movie_API_BASE_URL,movie);
    }

    getMovieById(movieId){
        return axios.get(Movie_API_BASE_URL + '/' + movieId);
    }

    updateMovie(movie, movieId){
        return axios.put(Movie_API_BASE_URL + '/' + movieId, movie);
    }

    deleteMovie(movieId){
        return axios.delete(Movie_API_BASE_URL + '/' + movieId);
    }
}

export default new MovieService()

































































































































































