import React, { Component } from 'react'
import MovieService from '../services/MovieService'
class ViewMovie extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            movie: {}
        }
    }

    componentDidMount(){
        MovieService.getMovieById(this.state.id).then( res => {
            this.setState({movie: res.data});
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Movie Details</h3>
                    <div className = "card-body">
                        <div className = "row">
                            <label> Movie Title: </label>
                            <div> { this.state.movie.movieTitle}</div>
                        </div>
                        <div className = "row">
                            <label> Language: </label>
                            <div> { this.state.movie.language }</div>
                        </div>
                        <div className = "row">
                            <label> Genere: </label>
                            <div> { this.state.movie.genere }</div>
                        </div>
                        <div className = "row">
                            <label> Rating: </label>
                            <div> { this.state.movie.rating }</div>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default ViewMovie
