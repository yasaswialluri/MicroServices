import React, { Component } from 'react'
import MovieService from '../services/MovieService'
 class CreateMovie extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            movieId: this.props.match.params.id,
            movieTitle: '',
            language: '',
            genere: '',
            rating:0
        }
        this.changeMovieTitleHandler = this.changeMovieTitleHandler.bind(this);
        this.changeLanguageHandler = this.changeLanguageHandler.bind(this);
        this.changeGenereHandler = this.changeGenereHandler.bind(this);
        this.changeRatingHandler = this.changeRatingHandler.bind(this);
        this.saveOrUpdateMovie = this.saveOrUpdateMovie.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.movieId === '_add'){
            return
        }else{
            MovieService.getMovieById(this.state.movieId).then( (res) =>{
                let movie = res.data;
                this.setState({movieTitle: movie.movieTitle,
                    language: movie.language,
                    genere : movie.genere,
                    rating : movie.rating

                });
            });
        }        
    }
    saveOrUpdateMovie = (e) => {
        e.preventDefault();
        let movie = {movieTitle: this.state.movieTitle, language: this.state.language, genere: this.state.genere,rating: this.state.rating};
        console.log('movie => ' + JSON.stringify(movie));

        // step 5
        if(this.state.movieId === '_add'){
            MovieService.createMovie(movie).then(res =>{
                this.props.history.push('/movie');
            });
        }else{
            MovieService.updateMovie(movie, this.state.movieId).then( res => {
                this.props.history.push('/movie');
            });
        }
    }
    
    changeMovieTitleHandler= (event) => {
        this.setState({movieTitle: event.target.value});
    }

    changeLanguageHandler= (event) => {
        this.setState({language: event.target.value});
    }

    changeGenereHandler= (event) => {
        this.setState({genere: event.target.value});
    }

    changeRatingHandler= (event) => {
        this.setState({rating: event.target.value});
    }
    cancel(){
        this.props.history.push('/movie');
    }

    getTitle(){
        if(this.state.movieId === '_add'){
            return <h3 className="text-center">Add Movie</h3>
        }else{
            return <h3 className="text-center">Update Movie</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Movie Title: </label>
                                            <input placeholder="Movie Title" name="movieTitle" className="form-control" 
                                                value={this.state.movieTitle} onChange={this.changeMovieTitleHandler}/>
                                        </div>
                                         <div>
                                             <label>Language</label>
                                            <select placeholder="Language" name="language" className="form-control" 
                                             value={this.state.language} onChange={this.changeLanguageHandler}>
                                                <option value="Hindhi">Hindhi</option>
                                                <option value="Telugu">Telugu</option>
                                                <option value="Tamil">Tamil</option>
                                                <option value="English">English</option>
                                            </select>
                                        </div>

                                        <div>
                                            <label>Genere</label>
                                            <select placeholder="Genere" name="genere" className="form-control" 
                                             value={this.state.genere} onChange={this.changeGenereHandler}>
                                                <option value="Horror">Horror</option>
                                                <option value="Action">Action</option>
                                                <option value="Comedy">Comedy</option>                 
                                            </select>
                                        </div> 

                                        <div>
                                            <label>Rating</label>
                                            <select placeholder="Rating" name="rating" className="form-control" 
                                             value={this.state.rating} onChange={this.changeRatingHandler}>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>  
                                                <option value="4">4</option>  
                                                <option value="5">5</option>                 
                                            </select>
                                        </div>            
                                        

                                        <button className="btn btn-success" onClick={this.saveOrUpdateMovie}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default CreateMovie
