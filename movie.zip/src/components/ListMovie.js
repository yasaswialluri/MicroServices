import React, { Component } from 'react'
import MovieService from '../services/MovieService'
class ListMovie extends Component {
    constructor(props) {
        super(props)

        this.state = {
                movies: []
        }
        this.addMovie = this.addMovie.bind(this);
        this.editMovie = this.editMovie.bind(this);
        this.deleteMovie = this.deleteMovie.bind(this);
    }

    deleteMovie(id){
        MovieService.deleteMovie(id).then( res => {
            this.setState({movies: this.state.movies.filter(movie => movie.movieId !== id)});
        });
    }
    viewMovie(id){
        this.props.history.push(`/view-movie/${id}`);
    }
    editMovie(id){
        this.props.history.push(`/add-movie/${id}`);
    }

    componentDidMount(){
MovieService.getMovie().then((res) => {
            this.setState({ movies: res.data});
        });
    }

    addMovie(){
        this.props.history.push('/add-movie/_add');
    }

    render() {
        return (
            <div>
                 <h2 className="text-center">Movie List</h2>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.addMovie}> Add Movie</button>
                 </div>
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th> Movie Id</th>
                                    <th> Movie Title</th>
                                    <th> language</th>
                                    <th> genere</th>
                                    <th>rating</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.movies.map(
                                        movie=> 
                                        <tr key = {movie.movieId}>
                                            <td>{movie.movieId}</td>
                                             <td> { movie.movieTitle} </td>   
                                             <td> {movie.language}</td>
                                             <td> {movie.genere}</td>
                                             <td> {movie.rating}</td>
                                             <td>
                                                 <button onClick={ () => this.editMovie(movie.movieId)} className="btn btn-info">Update </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteMovie(movie.movieId)} className="btn btn-danger">Delete </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewMovie(movie.movieId)} className="btn btn-info">View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
        )
    }
}

export default ListMovie
