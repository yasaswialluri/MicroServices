import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import ListMovie from './components/ListMovie';
import CreateMovie from './components/CreateMovie';
import ViewMovie from './components/ViewMovie';
import FooterComponent from './components/FooterComponent';
import HeaderComponent from './components/HeaderComponent';
function App() {
  return (
    <div>
        <Router>
              <HeaderComponent />
                <div className="container">
                    <Switch> 
                          <Route path = "/" exact component = {ListMovie}></Route>
                          <Route path = "/movie" component = {ListMovie}></Route>
                          <Route path = "/add-movie/:id" component = {CreateMovie}></Route>
                          <Route path = "/view-movie/:id" component = {ViewMovie}></Route>
                          {/* <Route path = "/update-employee/:id" component = {UpdateEmployeeComponent}></Route> */}
                    </Switch>
                </div>
              <FooterComponent />
        </Router>
    </div>
  );
}

export default App;
